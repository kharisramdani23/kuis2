<!-- footer.php -->
<!-- <footer class="footer">
  <div class="container">
    <p class="text-footer">
      Hak Cipta <a href="https://github.com/dosenhub">DosenHub</a>
    </p>
  </div>
</footer> -->